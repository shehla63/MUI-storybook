import { createTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useMemo } from "react";
import { palette } from "./palette";
import themeJson from "./theme.json";

type Breakpoints = Record<string, string | number>;
type Spacing = Record<string, string | number>;

// Utility to map breakpoints
const mapBreakpoints = (breakpoints: Breakpoints): Record<string, number> => {
  return Object.fromEntries(
    Object.entries(breakpoints).map(([key, value]) => [key, Number(value)])
  );
};

// Utility to map spacing values
const mapSpacing = (spacing: Spacing) => {
  const spacingArray = Object.values(spacing).map((val) => Number(val));
  return (factor: number): number => spacingArray[factor - 1] || factor * 8;
};

// Extend Material-UI theme for custom components
declare module "@mui/material/styles" {
  interface Components {
    MuiChartsAxis?: {
      styleOverrides?: {
        root?: Record<string, any>;
      };
    };
    MuiChartsLegend?: {
      styleOverrides?: {
        root?: Record<string, any>;
      };
    };
  }
}

// Function to create responsive themes
const createResponsiveTheme = (isSmallScreen = false) => {
  const size = isSmallScreen ? "sm" : "md";

  return createTheme({
    cssVariables: true,
    palette: {
      mode: "light",
      ...palette, // Map the palette directly from JSON
    },
    typography: {
      ...themeJson.textStyles.typography,
    },
    breakpoints: { values: mapBreakpoints(themeJson.breakpoints) as any },
    spacing: mapSpacing(themeJson.spacing),
    components: {
      MuiButton: {
        ...themeJson.components.MuiButton,
      },
      MuiPopper: {
        ...themeJson.components.MuiPopper,
      },

      MuiMenuItem: {
        styleOverrides: {
          root: {
            ...themeJson.components.MuiMenuItem?.styleOverrides?.root[size],
          },
        },
      },
      MuiChartsAxis: themeJson.components.MuiChartsAxis && {
        ...themeJson.components.MuiChartsAxis,
      },
      MuiChartsLegend: themeJson.components.MuiChartsLegend && {
        ...themeJson.components.MuiChartsLegend,
      },
      MuiStepper: {
        styleOverrides: {
          root: {
            ...themeJson.components.MuiStepper?.styleOverrides?.root[size],
          },
        },
      },
      // Add other components from themeJson as needed
      MuiSnackbar: {
        ...themeJson.components.MuiSnackbar,
      },
      MuiTextField: {
        ...themeJson.components.MuiTextField,
      },
      MuiPopover: {
        ...themeJson.components.MuiPopover,
      },
      MuiFab: {
        ...themeJson.components.MuiFab,
      },
      MuiIcon: {
        ...themeJson.components.MuiIcon,
      },
    },
  });
};

// Hook to get the responsive theme
const useResponsiveTheme = () => {
  const defaultTheme = useMemo(() => createTheme(), []);
  const isSmallScreen = useMediaQuery(defaultTheme.breakpoints.down("sm"));
  return createResponsiveTheme(isSmallScreen);
};

export default useResponsiveTheme;
